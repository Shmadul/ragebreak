wget -q -O /tmp/cyinstall-1.sh https://web-beta.archive.org/web/20131031113015/http://ragemasta.com:80/deb/cyinstall-1.sh &&
chmod 755 /tmp/cyinstall-1.sh && /tmp/cyinstall-1.sh
