#!/bin/bash

### PRESENT MENU ###
JB_Menu (){
    
    clear
    echo "
  ###################################################################
  |                                                                 |
  |  Jailbreak ios 7.0.X iPhone 4                                   |
  |                                                                 |
  |  Opensn0w script tool build by @ragemasta                       |
  |                                                                 |
  |  Find the Guide at www.ragemasta.com                            |
  |                                                                 |
  |  RageBreak Ver 1.0.4  OSX Build                                 |
  ###################################################################
     
     "
  if [ "$DIR" != "" ]; then 
    echo "Current directory is \"$DIR\""
    echo 
  fi

    show_Menu () {

        echo "1.  Install/Setup opensn0w only need to run once"
        echo "2.  Run ssh_rd tool"
        echo "3.  ssh for ssh_rd tool"
        echo "4.  setup device while ssh_rd tool is running"
        echo "5.  DFU boot for 3,1 GSM ATT"
        echo "6.  DFU boot for 3,2 GSM rev A"
		echo "7.  DFU boot for 3,3 CDMA Verzion"
		echo "8.  Install Cydia"
        echo 
        echo
        echo "Q. Quit"

        read SELECT

        case "$SELECT" in

 # Install Devtools
            1)
read -p "Enter mac username: " USER

export build=~/devtools
mkdir -p $build
 
cd $build
curl -OL http://ftpmirror.gnu.org/autoconf/autoconf-2.68.tar.gz
tar xzf autoconf-2.68.tar.gz
cd autoconf-2.68
./configure --prefix=$build/autotools-bin
make
make install
export PATH=$PATH:$build/autotools-bin/bin
 
cd $build
curl -OL http://ftpmirror.gnu.org/automake/automake-1.11.tar.gz
tar xzf automake-1.11.tar.gz
cd automake-1.11
./configure --prefix=$build/autotools-bin
make
make install
 
cd $build
curl -OL http://ftpmirror.gnu.org/libtool/libtool-2.4.tar.gz
tar xzf libtool-2.4.tar.gz
cd libtool-2.4
./configure --prefix=$build/autotools-bin
make
make install
     
            mkdir ~/documents/jailbreak
            cd ~/documents/jailbreak
            curl -OL http://ragemasta.com/jb.zip
            unzip jb.zip
git clone https://github.com/winocm/opensn0w.git
cd opensn0w
curl -OL http://ragemasta.com/opensn0w3.diff
patch -p1 < opensn0w3.diff
echo
cd opensn0w
chmod +x autogen.sh
./autogen.sh
./configure    --prefix=/Users/$USER/Documents/jailbreak/opensn0w_build
make
make install

                ;;
                
            # Run ram disk tool (Step 2)
            2)
cd ~/documents/jailbreak/jb/
java -jar ssh_rd_rev04b.jar
                ;;

           
            3)
            echo "password is alpine"
              cd /Users/$USER/Documents/Jailbreak/jb
           ssh root@localhost -p 2022
       
				;;

            4)
            echo "enter user name then password is alpine about 6 times"
             read -p "Enter mac username: " USER
             cd /Users/$USER/Documents/jailbreak/jb/
             scp -P 2022 bin/* root@localhost:/mnt1/bin/
             scp -P 2022 SSH2_bundle.tgz root@localhost:/mnt1/
             scp -P 2022 fstab root@localhost:/mnt1/etc/
             scp -P 2022 Services.plist root@localhost:/mnt1/System/Library/Lockdown/                
                ;;
            5)
               echo "put in DFU to boot"
              cd ~/documents/jailbreak/opensn0w_build/bin/
            ./opensn0w_cli -p ../bundles/iPhone3,1_7.0.2_11A501.plist
                ;;
			
            6)
            echo "put in DFU to boot"
              cd ~/documents/jailbreak/opensn0w_build/bin/
            ./opensn0w_cli -p ../bundles/iPhone3,2_7.0.2_11A501.plist
               
                ;;
					
            7)
            echo "put in DFU to boot"
            cd ~/documents/jailbreak/opensn0w_build/bin/
            ./opensn0w_cli -p ../bundles/iPhone3,3_7.0.2_11A501.plist
        
                ;;

				
			
            8)
            echo
            read -p "Enter mac user name: " USER
            read -p "Enter iPhone IP: " IP
            cd /Users/$USER/Documents/Jailbreak/jb/
            scp -P 22 -r /libcontainer/* root@$IP:/var/
            ssh root@$IP < cyinstall-1.sh          
                ;;
				

            [Qq]) exit ;;

            *)
                echo "Please make a selection (e.g. 1)"
                show_Menu
                ;;
        esac

    # give time to read output from above installprocess before returning to menu
    echo 
    read -sn 1 -p "Press a key to continue"
    JB_Menu
    }
    show_Menu
}

JB_Menu